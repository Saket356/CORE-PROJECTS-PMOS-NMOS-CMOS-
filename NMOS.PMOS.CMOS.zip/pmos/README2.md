# PMOS Transistor Simulation using LTspice ⚙️

This project involves the design and simulation of a **PMOS transistor** using **LTspice**. It focuses on analyzing the **input** and **output characteristics**, which are essential for understanding PMOS behavior in analog and digital circuits.

## Overview 📘

The project simulates:
- **Input Characteristics**: I<sub>D</sub> vs V<sub>SG</sub> at fixed V<sub>SD</sub>
- **Output Characteristics**: I<sub>D</sub> vs V<sub>SD</sub> for different V<sub>SG</sub> values

These plots help identify PMOS operating regions — **cutoff**, **linear (triode)**, and **saturation**.

## Tools Used 🛠️

- **LTspice XVII** – Analog circuit simulator
- **MOSFET Theory** – PMOS modeling and analysis

## Key Highlights ✅

- Built PMOS circuits for DC sweep simulations
- Analyzed behavior across different V<sub>SG</sub> and V<sub>SD</sub> values
- Visualized characteristic curves to study threshold voltage and switching regions

## How to Run 🚀

1. Open `.asc` schematic files in LTspice
2. Run the `.dc` sweep simulations
3. Use the probe to plot I<sub>D</sub> vs V<sub>SG</sub> or V<sub>SD</sub> and observe behavior
