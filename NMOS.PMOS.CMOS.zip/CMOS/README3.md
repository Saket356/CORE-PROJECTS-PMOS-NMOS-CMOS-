# CMOS Inverter Simulation using LTspice ⚙️

This project demonstrates the design and simulation of a **CMOS inverter** using **PMOS** and **NMOS transistors** in **LTspice**. It focuses on analyzing the inverter's **input-output (transfer) characteristics** to understand its switching behavior.

## Overview 📘

- A CMOS inverter was realized by combining a **PMOS** transistor at the top and an **NMOS** transistor at the bottom.
- A DC sweep was performed at the input to observe the voltage transfer characteristics (VTC).
- The simulation highlights the inverter behavior and transition region.

## Tools Used 🛠️

- **LTspice XVII** – Analog/digital circuit simulator
- **MOSFET Theory** – CMOS logic fundamentals

## Key Highlights ✅

- Designed a standard CMOS inverter using one PMOS and one NMOS.
- Simulated the **transfer characteristics** (V<sub>out</sub> vs V<sub>in</sub>).
- Identified:
  - Logic threshold (V<sub>th</sub>)
  - High/low output voltage levels
  - Sharp switching behavior

## How to Run 🚀

1. Open the CMOS inverter schematic `.asc` file in LTspice.
2. Run a `.dc` sweep on the input voltage (V<sub>in</sub>).
3. Use the probe tool to plot the inverter transfer curve: **V<sub>out</sub> vs V<sub>in</sub>**.
