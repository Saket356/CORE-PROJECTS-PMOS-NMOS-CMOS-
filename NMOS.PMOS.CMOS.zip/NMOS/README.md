# NMOS Transistor Simulation using LTspice ⚙️

This project involves the design and simulation of an **NMOS transistor** using **LTspice**. It focuses on analyzing the **input** and **output characteristics** of the device, which are fundamental to understanding MOSFET behavior in VLSI circuits.

## Overview 📘

The project simulates:
- **Input Characteristics**: I<sub>D</sub> vs V<sub>GS</sub> at fixed V<sub>DS</sub>
- **Output Characteristics**: I<sub>D</sub> vs V<sub>DS</sub> for different V<sub>GS</sub> values

These help identify the NMOS operating regions — **cutoff**, **triode**, and **saturation**.

## Tools Used 🛠️

- **LTspice XVII** – Analog circuit simulation
- **MOSFET Theory** – Semiconductor fundamentals

## Key Highlights ✅

- Simulated characteristic curves using DC sweeps
- Observed threshold voltage and behavior transitions
- Gained hands-on experience with NMOS modeling in LTspice

## How to Run 🚀

1. Open `.asc` files in LTspice
2. Run the `.dc` sweep simulations
3. Plot I<sub>D</sub> vs V<sub>GS</sub> or V<sub>DS</sub> using the probe
